package com.example.eshoppro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eshoppro.Adapters.CartAdapter;
import com.example.eshoppro.Data.FoodData;

import java.util.ArrayList;
import java.util.List;

public class MycartActivity extends AppCompatActivity {
    List<FoodData> foodDataList;
    TextView tv_item_count,tv_total;
    RecyclerView recyclerView;
    int price = 0;
    ImageView imageView_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycart);
        tv_item_count=findViewById(R.id.tv_count_item);
        recyclerView=findViewById(R.id.recyclerview_cart);
        imageView_back=findViewById(R.id.img_back);
        tv_total=findViewById(R.id.tv_total_amount);
        //img_back
        imageView_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MycartActivity.this,FoodsActivity.class);
                startActivity(intent);
            }
        });

Intent intent =getIntent();
Bundle bundle=intent.getBundleExtra("BundleData");
foodDataList=(ArrayList<FoodData>)bundle.getSerializable("checkedlist");

        Log.i("Cart Data",""+foodDataList.size());

        tv_item_count.setText(String.valueOf(foodDataList.size()));

        //total price
        for (int i =0; i<foodDataList.size(); i++){
            FoodData data = foodDataList.get(i);
            price = price + Integer.parseInt(data.getFoodprice());
        }

        tv_total.setText("Total amount : $ "+price);

//set recyclerview
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CartAdapter cartAdapter=new CartAdapter(this,foodDataList);
        recyclerView.setAdapter(cartAdapter);


    }
}
