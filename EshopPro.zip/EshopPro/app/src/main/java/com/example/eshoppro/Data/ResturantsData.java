package com.example.eshoppro.Data;

public class ResturantsData {

    String res_name;
    String res_add;
    String res_image;

    public String getRes_rating() {
        return res_rating;
    }

    public void setRes_rating(String res_rating) {
        this.res_rating = res_rating;
    }

    String res_rating;

    public ResturantsData(){}

    public String getRes_name() {
        return res_name;
    }

    public void setRes_name(String res_name) {
        this.res_name = res_name;
    }

    public String getRes_add() {
        return res_add;
    }

    public void setRes_add(String res_add) {
        this.res_add = res_add;
    }

    public String getRes_image() {
        return res_image;
    }

    public void setRes_image(String res_image) {
        this.res_image = res_image;
    }
}
