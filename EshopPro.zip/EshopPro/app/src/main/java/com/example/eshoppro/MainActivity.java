package com.example.eshoppro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Runnable runnable =new Runnable() {
            @Override
            public void run() {
                Intent intent =new Intent(MainActivity.this,OnboardingActivity.class);
                startActivity(intent);
                finish();
            }
        };

        Handler handler=new Handler();
        handler.postDelayed(runnable,700);
    }
}
