package com.example.eshoppro.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eshoppro.Data.FoodData;
import com.example.eshoppro.R;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.Myviewholder>{
    Context context;
    List<FoodData> cartlist;

    public CartAdapter(Context context, List<FoodData> cartlist) {
        this.context = context;
        this.cartlist = cartlist;
    }

    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item,parent,false);
        Myviewholder myviewholder =new Myviewholder(view);
        return myviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull final Myviewholder holder, final int position) {
        final  FoodData cartData= cartlist.get(position);
        holder.img_item_image.setImageResource(cartData.getImageId());
        holder.tv_itemname.setText(cartData.getFoodname());
        holder.tv_item_price.setText(cartData.getFoodprice());

        //button remove
        holder.btn_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //remove itemfrom list
                cartlist.remove(holder.getAdapterPosition());
                //remove item from recyclerview
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });

    }

    @Override
    public int getItemCount() {
        //no of rows
        return cartlist.size();
    }

    public class Myviewholder extends RecyclerView.ViewHolder {
        TextView tv_itemname,tv_item_price;
        ImageView img_item_image;
        Button btn_remove;

        public Myviewholder(@NonNull View itemView) {
            super(itemView);

            tv_itemname=itemView.findViewById(R.id.tv_cart_itemname);
            tv_item_price=itemView.findViewById(R.id.tv_cart_price);
            img_item_image=itemView.findViewById(R.id.img_cart_item);
            btn_remove=itemView.findViewById(R.id.btn_remove);
        }
    }


}
