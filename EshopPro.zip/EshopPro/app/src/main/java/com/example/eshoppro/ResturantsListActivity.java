package com.example.eshoppro;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.eshoppro.Adapters.ResturantsRecylerViewAdapter;
import com.example.eshoppro.Data.ResturantsData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ResturantsListActivity extends AppCompatActivity {

    List<ResturantsData> resturantsDataList = new ArrayList<>();

    ResturantsRecylerViewAdapter adapter;
    LinearLayoutManager linearLayoutManager;

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resturants_list);

        recyclerView = (RecyclerView)findViewById(R.id.recylerview);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new ResturantsRecylerViewAdapter(this, resturantsDataList);

        recyclerView.setAdapter(adapter);

        callAPIForResturnts();

    }


    public void callAPIForResturnts(){

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=22.570982,88.4324729&radius=5000&types=food|restaurant&key=AIzaSyAo5dHDJWNc_ruqDioI5hi4OcwculTYAzU";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        Log.d(">>Response","="+response);

                        try {

                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("results");

                            for(int i = 0; i<jsonArray.length();i++){

                                JSONObject resObject = jsonArray.getJSONObject(i);

                                String resName = resObject.optString("name");
                                String resAddress = resObject.optString("vicinity");
                                String resRating = resObject.optString("rating");

                                JSONArray photosArray = resObject.getJSONArray("photos");
                                String photRefe = photosArray.getJSONObject(0).optString("photo_reference");

                                String resImgUrl = getImageUrlFromReference(photRefe);


                                ResturantsData data = new ResturantsData();
                                data.setRes_name(resName);
                                data.setRes_add(resAddress);
                                data.setRes_image(resImgUrl);
                                data.setRes_rating(resRating);
                                resturantsDataList.add(data);
                            }

                            //refresh the adapter
                            adapter.notifyDataSetChanged();

                        }catch (Exception e){

                        }
                        progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(">>Error","="+error);
                progressDialog.dismiss();

            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);


    }


    public String getImageUrlFromReference(String refence){

        String url = "https://maps.googleapis.com/maps/api/place/photo?photoreference="
                +refence+
                "&sensor=false&maxheight=200&maxwidth=500&key=AIzaSyAo5dHDJWNc_ruqDioI5hi4OcwculTYAzU";

        return url;
    }

}
