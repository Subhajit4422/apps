package com.example.eshoppro;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eshoppro.Adapters.FoodAdapter;
import com.example.eshoppro.Adapters.SliderAdapterExample;
import com.example.eshoppro.Data.FoodData;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    Button btn_menu,btn_ok;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ImageView imageView_resturant,imgv_pizza;
    LinearLayout lay_contain;
    LocationManager locationManager;
    LocationListener locationListener;
    TextView tv_current_location;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        imageView_resturant=findViewById(R.id.imv_resturant);
        imgv_pizza=findViewById(R.id.img_pizza);
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        btn_menu = (Button)findViewById(R.id.btn_menu);
        navigationView = (NavigationView)findViewById(R.id.navigation_view);
        lay_contain=findViewById(R.id.lay_container);
        tv_current_location=findViewById(R.id.tv_current_address);
        btn_ok=findViewById(R.id.btn_ok);

        //mycartImage
        imageView_resturant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,ResturantsListActivity.class);
                startActivity(intent);
            }
        });
        //Imageview Pizza
        imgv_pizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(HomeActivity.this,FoodsActivity.class);
                startActivity(intent);
            }
        });

        //four item
        lay_contain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(HomeActivity.this,FoodsActivity.class);
                startActivity(intent);
            }
        });

        //call btn
        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Open drawer
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
//add click event to menu items
        navigationView.setNavigationItemSelectedListener(HomeActivity.this); //implement from here menuitem selected

        //Geo Coder current location
        locationManager =(LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
      btn_ok.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              //do
              Toast.makeText(HomeActivity.this, "Please on your GPS", Toast.LENGTH_SHORT).show();
              locationListener =new LocationListener() {
                  @Override
                  public void onLocationChanged(Location location) {
                      Log.i("Location",location.toString());

                      // Toast.makeText(MainActivity.this, ""+location.toString(), Toast.LENGTH_SHORT).show();
//here the code of geocoder
                      Geocoder geocoder =new Geocoder(getApplicationContext(), Locale.getDefault());
                      try {
                          List<Address> listAddress=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
                          if (listAddress!=null&&listAddress.size()>0)
                          {
                              Log.i("placeinfo",listAddress.get(0).toString());
                              //tv_loc.setText(listAddress.get(0).toString());
                              String address="";
                              //get(0) means first address object
                              if (listAddress.get(0).getPostalCode()!=null)
                              {
                                  address+=listAddress.get(0).getPostalCode()+", "; //this is the Pincode
                              }
                              if (listAddress.get(0).getCountryName()!=null)
                              {
                                  address+=listAddress.get(0).getCountryName()+", "; //this is the state
                              }
                              if (listAddress.get(0).getAdminArea()!=null)
                              {
                                  address+=listAddress.get(0).getAdminArea()+", "; //this is the state
                              }
                              if (listAddress.get(0).getLocality()!=null)
                              {
                                  address+=listAddress.get(0).getLocality(); //this is the city
                              }

                              tv_current_location.setText(address); //set the address

                          }
                      } catch (IOException e) {
                          e.printStackTrace();
                      }
                  }

                  @Override
                  public void onStatusChanged(String provider, int status, Bundle extras) {

                  }

                  @Override
                  public void onProviderEnabled(String provider) {

                  }

                  @Override
                  public void onProviderDisabled(String provider) {

                  }
              };

              //check permission
              if (ContextCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED)
              {
                  ActivityCompat.requestPermissions(HomeActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
              }
              //if permission is already granted runs else statement
              else
              {
                  locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
              }
          }
      });


    //oncreate ends
    }

    //direct backpress event

    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            // Yes then close drawer
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    //menu item selected
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id =menuItem.getItemId();

        if(id==R.id.menu_call)
        {
            Intent intent =new Intent(HomeActivity.this,CallActivity.class);
            startActivity(intent);
        }

        else if (id==R.id.menu_fashion)
        {
            Toast.makeText(this,"Fashion Clicked",Toast.LENGTH_SHORT).show();
            loadFragment(new FashionFragment());
        }
        else if (id==R.id.menu_foods)
        {
            Intent intent =new Intent(HomeActivity.this,FoodsActivity.class);
            startActivity(intent);
        }
        else if (id==R.id.menu_resturants)
        {
            Intent intent =new Intent(HomeActivity.this,ResturantsListActivity.class);
            startActivity(intent);
        }
        else if (id==R.id.menu_account)
        {
            Toast.makeText(this,"Account Clicked",Toast.LENGTH_SHORT).show();

        }
        else if (id==R.id.menu_signout)
        {
            signOut();
            Toast.makeText(getApplicationContext(),"Signed Out Successfully",Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(HomeActivity.this,MobileNoActivity.class);
            startActivity(intent);
        }
//close drawer
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public void loadFragment(Fragment fragment)
    {
        FragmentManager fragmentManager =getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.lay_container,fragment);
        fragmentTransaction.commit();
    }

    //signout
    public void signOut() {
        // [START auth_sign_out]
        FirebaseAuth.getInstance().signOut();
        // [END auth_sign_out]
    }

    //location permission
    //outside main
    //request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            }

        }
    }

}

