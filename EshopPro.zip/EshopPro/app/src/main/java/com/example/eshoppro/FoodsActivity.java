package com.example.eshoppro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.eshoppro.Adapters.FoodAdapter;
import com.example.eshoppro.Data.FoodData;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class FoodsActivity extends AppCompatActivity {
    Button btn_add_to_cart,btn_previous;
    Button btn_order;
    ImageView imageView;

    ArrayList<FoodData> foodDataArrayList=new ArrayList<>();
    String[] foodname = {"Steak","Meat","Apple","Bacon","Banana","Barbecue","Bread","Burger","Cake","Cannedsardines"};

    int[] food_image_id={R.drawable.item_steak,R.drawable.item_meat,R.drawable.apple,R.drawable.bacon,R.drawable.banana,
            R.drawable.barbecue,R.drawable.bread,R.drawable.burger,R.drawable.cake,R.drawable.cannedsardines};

    String[] foodprice={"100","200","210","300","208","160","145","213","124","86"};

    RecyclerView recyclerView;
    private FoodAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foods);

        imageView=findViewById(R.id.imv_mycart);
        btn_order=findViewById(R.id.btn_order);
        btn_add_to_cart = findViewById(R.id.btn_add_to_cart);
        btn_previous=findViewById(R.id.btn_prev);

        recyclerView=findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //specify adapter

        for (int i=0;i<foodname.length;i++)
        {
            FoodData foodData =new FoodData();
            foodData.setFoodname(foodname[i]);
            foodData.setImageId(food_image_id[i]);
            foodData.setFoodprice(foodprice[i]);
            foodDataArrayList.add(foodData);
        }
        mAdapter =new FoodAdapter(this,foodDataArrayList);
        recyclerView.setAdapter(mAdapter);
//button previous activity
        btn_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(FoodsActivity.this,HomeActivity.class);
                startActivity(intent);
            }
        });

        //mycartImage
        /*
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FoodsActivity.this,MycartActivity.class);
                startActivity(intent);
            }
        }); */

//button proceed to cart
        btn_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<FoodData> checkedlist =new ArrayList<>();
                for (int i=0;i<foodDataArrayList.size();i++)
                {
                    //add each item to fooddata object
                    FoodData foodData =foodDataArrayList.get(i);
                    if (foodData.isClicked())
                    {
                        checkedlist.add(foodData);
                    }
                }
                Log.i("Checked list",""+checkedlist.size());
                //now pass checkedlist data
                Bundle bundle =new Bundle();
                bundle.putSerializable("checkedlist", (Serializable) checkedlist);

                Intent intent =new Intent(FoodsActivity.this,MycartActivity.class);
                intent.putExtra("BundleData",bundle);
                startActivity(intent);
            }
        });

      //end of oncreate method
    }
}
