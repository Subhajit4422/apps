package com.example.eshoppro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MobileNoActivity extends AppCompatActivity {
EditText ed_mobile_number,ed_otp;
Button btn_submit,btn_login;

private FirebaseAuth mAuth;
public String CodeSent;
RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_no);
        ed_mobile_number=findViewById(R.id.ed_mobile_number);
        ed_otp=findViewById(R.id.ed_otp);
        btn_submit=findViewById(R.id.btn_submit);
        btn_login=findViewById(R.id.btn_login);
        relativeLayout=findViewById(R.id.lay_mobileno);
//initialy make otp button invisible
        ed_otp.setVisibility(View.GONE);
        btn_login.setVisibility(View.GONE);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

btn_submit.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        sendVerificationCode();
        if (ed_mobile_number.getText().toString().length()==10)
        {
            ed_mobile_number.setVisibility(View.GONE);
            btn_submit.setVisibility(View.GONE);
            //now make visible otp button

            ed_otp.setVisibility(View.VISIBLE);
            btn_login.setVisibility(View.VISIBLE);
        }
    }
});

btn_login.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (ed_otp.getText().toString().trim().isEmpty()||ed_otp.getText().toString().trim().length()<6)
        {
            ed_otp.setError("Invalid Code");
            ed_mobile_number.requestFocus();
            return;
        }
        verifyOTPcode();
    }
});

    }

    private void sendVerificationCode()
    {
        String phoneNumber ="+91"+ed_mobile_number.getText().toString().trim();

        if (phoneNumber.isEmpty()||phoneNumber.length()<10)
        {
            ed_mobile_number.setError("Phone Number Is Required");
            ed_mobile_number.requestFocus();
            return;
        }
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {

        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            CodeSent =s ;//code sent to the user
            Toast.makeText(getApplicationContext(),"OTP sent to you",Toast.LENGTH_SHORT).show();
        }
    };


    private void verifyOTPcode()
    {
        String receivedCode =ed_otp.getText().toString().trim();
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSent, receivedCode);
      signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(MobileNoActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent(MobileNoActivity.this,HomeActivity.class);
                             startActivity(intent);
                             finish();

                        } else {
                            // Sign in failed, display a message and update the UI
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(MobileNoActivity.this, "Incorrect Code", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

}
