package com.example.eshoppro.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;
import com.example.eshoppro.Data.ResturantsData;
import com.example.eshoppro.R;

import java.util.List;

public class ResturantsRecylerViewAdapter extends RecyclerView.Adapter<ResturantsRecylerViewAdapter.MyViewHolder> {

    Context context;
    List<ResturantsData> resturantsDataList;

    public ResturantsRecylerViewAdapter(Context context, List<ResturantsData> resturantsDataList){

        this.resturantsDataList = resturantsDataList;
        this.context = context;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_res, parent, false);

        MyViewHolder viewHolder = new MyViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

      ResturantsData data = resturantsDataList.get(position);
      holder.tv_name.setText(data.getRes_name());
      holder.tv_add.setText(data.getRes_add());
      holder.tv_rate.setText(data.getRes_rating());

        Glide.with(context).load(data.getRes_image()).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return resturantsDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tv_name, tv_add, tv_rate;
        ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_name = itemView.findViewById(R.id.tv_name);
            tv_add = itemView.findViewById(R.id.tv_add);
            imageView = itemView.findViewById(R.id.img_res);
            tv_rate = itemView.findViewById(R.id.tv_rate);

        }
    }
}
