package com.example.eshoppro.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eshoppro.Data.FoodData;
import com.example.eshoppro.R;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.MyviewHolder> {
    String state="on";
    Context context;
    ArrayList<FoodData> foodDataArrayList;
    Boolean isButtonClicked = false;

    public FoodAdapter(Context context, ArrayList<FoodData> foodDataArrayList) {
        this.context = context;
        this.foodDataArrayList = foodDataArrayList;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.fooditem,parent,false);
        MyviewHolder myviewHolder =new MyviewHolder(view);
        return myviewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyviewHolder holder, int position) {
final FoodData foodData=foodDataArrayList.get(position);

holder.img_item.setImageResource(foodData.getImageId());
holder.tv_itemname.setText(foodData.getFoodname());
holder.tv_itemprice.setText(foodData.getFoodprice());


//button add to cart
        holder.btn_addtocart_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //do
                foodData.setClicked(holder.btn_addtocart_item.isClickable());
                int whiteColorValue = Color.parseColor("#FFFFFFFF");
                int greenColorValue = Color.parseColor("#FF00BFA5");
                if (v.getId() == R.id.btn_add_to_cart) {

                    isButtonClicked =!isButtonClicked; // toggle the boolean flag
                    v.setBackgroundResource(isButtonClicked ? R.drawable.round_corner_button : R.drawable.round_corner_border);
                    holder.btn_addtocart_item.setText(isButtonClicked ? "Added":"+  Add");
                    holder.btn_addtocart_item.setTextColor(isButtonClicked ? whiteColorValue:greenColorValue);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return foodDataArrayList.size();
    }

    public static class MyviewHolder extends RecyclerView.ViewHolder
{
    TextView tv_itemname,tv_itemprice;
    ImageView img_item;
    CheckBox checkBox;
    Button btn_addtocart_item;
    public MyviewHolder(@NonNull View itemView) {
        super(itemView);
        this.setIsRecyclable(false);

     tv_itemname=itemView.findViewById(R.id.tv_foodname);
     tv_itemprice=itemView.findViewById(R.id.tv_foodprice);
     img_item=itemView.findViewById(R.id.img_item);
     btn_addtocart_item=itemView.findViewById(R.id.btn_add_to_cart);

    }
}
}
